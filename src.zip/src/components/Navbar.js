"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import clsx from "clsx";
import Icon from "./Icon";
import ThemeSwitcher from "./ThemeSwitcher";

const LINKS = [
  { href: "/about", en: "About Us", id: "Tentang Kami" },
  { href: "/personnel", en: "Personnel", id: "Personalia" },
  { href: "/program", en: "Program", id: "Program" },
  { href: "/activities", en: "Weekly Activities", id: "Kegiatan Mingguan" },
  { href: "/mission", en: "Mission Trip", id: "Misi Perjalanan" },
  { href: "/care", en: "M-YES Care", id: "M-YES Care" },
  { href: "/news", en: "News", id: "Berita" },
  { href: "/contact", en: "Contact Us", id: "Hubungi Kami" },
];

function setLangCookie(l) {
  document.cookie = `lang=${l}; path=/; max-age=${60 * 60 * 24 * 365}; samesite=lax`;
}

export default function Navbar({ lang = "en" }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Tutup drawer saat pindah halaman
  const [lastPath, setLastPath] = useState(pathname);
  if (lastPath !== pathname) {
    setLastPath(pathname);
    setOpen(false);
  }

  // Kunci scroll body saat drawer terbuka + tutup dengan Esc
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const switchLang = (l) => {
    setLangCookie(l);
    router.refresh();
  };

  const isActive = (href) => pathname === href || pathname?.startsWith(`${href}/`);

  const langToggle = (className) => (
    <div className={clsx("flex items-center rounded-xl bg-ink/5 p-1", className)} role="group" aria-label="Language">
      {["en", "id"].map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => switchLang(l)}
          aria-pressed={lang === l}
          className={clsx("min-h-9 min-w-10 rounded-lg px-2 text-xs font-bold uppercase transition", lang === l ? "bg-surface text-primary-strong shadow-sm" : "text-ink-muted hover:text-ink")}
        >
          {l}
        </button>
      ))}
    </div>
  );

  return (
    <>
      <header className={clsx("sticky top-0 z-50 border-b transition-[background-color,border-color,box-shadow] duration-300", scrolled ? "border-line bg-surface/95 shadow-sm" : "border-transparent bg-bg/90")}>
        <nav className="mx-auto flex w-full max-w-7xl px-4 sm:px-6 lg:px-8 h-[var(--nav-h)] items-center gap-3" aria-label={lang === "id" ? "Menu utama" : "Main menu"}>
          <Link href="/" className="flex min-w-0 items-center gap-2.5" aria-label="M-YES — Home">
            <Image src="/logo-myes.png" alt="Logo M-YES" width={44} height={44} priority className="h-10 w-10 shrink-0 object-contain sm:h-11 sm:w-11" />
            <span className="min-w-0 leading-tight">
              <span className="block font-display text-lg font-extrabold tracking-tight">M-YES</span>
              <span className="hidden truncate text-[11px] font-medium text-ink-soft xs:block xl:hidden 2xl:block">Manado Youth English Service</span>
            </span>
          </Link>

          <ul className="ml-auto hidden items-center gap-0.5 xl:flex">
            {LINKS.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  aria-current={isActive(l.href) ? "page" : undefined}
                  className={clsx("flex min-h-11 items-center whitespace-nowrap rounded-lg px-2.5 text-[13.5px] font-semibold transition", isActive(l.href) ? "bg-primary-soft text-primary-strong" : "text-ink-muted hover:bg-ink/5 hover:text-ink")}
                >
                  {lang === "id" ? l.id : l.en}
                </Link>
              </li>
            ))}
          </ul>

          <div className="ml-auto flex items-center gap-1 xl:ml-2">
            {langToggle("hidden sm:flex")}
            <ThemeSwitcher lang={lang} />
            <button type="button" className="icon-btn xl:hidden" aria-label={lang === "id" ? "Buka menu" : "Open menu"} aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(true)}>
              <Icon name="menu" size={24} />
            </button>
          </div>
        </nav>
      </header>

      {/* Drawer HP: panel dari kanan, link muncul bertahap */}
      {open && (
        <div className="fixed inset-0 z-[60] xl:hidden" role="dialog" aria-modal="true" aria-label="Menu" id="mobile-menu">
          <button type="button" aria-label={lang === "id" ? "Tutup menu" : "Close menu"} className="animate-fade-in absolute inset-0 bg-ink/40" onClick={() => setOpen(false)} />
          <div className="animate-slide-in-right absolute inset-y-0 right-0 flex w-[min(86vw,360px)] flex-col bg-surface shadow-lift pb-safe">
            <div className="flex h-[var(--nav-h)] items-center justify-between border-b border-line px-4">
              <span className="font-display text-lg font-extrabold">Menu</span>
              <button type="button" className="icon-btn" aria-label={lang === "id" ? "Tutup menu" : "Close menu"} onClick={() => setOpen(false)} autoFocus>
                <Icon name="close" size={24} />
              </button>
            </div>
            <ul className="flex-1 space-y-1 overflow-y-auto p-3">
              {[{ href: "/", en: "Home", id: "Beranda" }, ...LINKS].map((l, i) => (
                <li key={l.href} className="animate-fade-up" style={{ animationDelay: `${40 + i * 35}ms` }}>
                  <Link
                    href={l.href}
                    onClick={() => setOpen(false)}
                    aria-current={pathname === l.href ? "page" : undefined}
                    className={clsx("flex min-h-12 items-center justify-between rounded-xl px-4 text-base font-semibold transition", pathname === l.href ? "bg-primary-soft text-primary-strong" : "text-ink hover:bg-ink/5")}
                  >
                    {lang === "id" ? l.id : l.en}
                    <Icon name="chevron-right" size={18} className="text-ink-soft" />
                  </Link>
                </li>
              ))}
            </ul>
            <div className="flex items-center justify-between gap-3 border-t border-line p-4">
              {langToggle()}
              <Link href="/contact" onClick={() => setOpen(false)} className="btn-primary">
                {lang === "id" ? "Gabung" : "Join Us"}
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
