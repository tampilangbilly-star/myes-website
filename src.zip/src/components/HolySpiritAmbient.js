import Image from "next/image";

/**
 * Merpati Roh Kudus — terbang masuk lalu melayang pelan.
 * Dipasang di DALAM area foto hero (pojok kanan atas), pointer-events: none,
 * sehingga tidak pernah menutupi teks atau tombol.
 */
export default function HolySpiritAmbient() {
  return (
    <div aria-hidden className="pointer-events-none absolute right-[4%] top-[5%] z-[1] w-[22%] max-w-[150px] min-w-[74px] sm:w-[16%] lg:right-[6%] lg:top-[8%] lg:w-[13%]">
      <div className="ray-pulse absolute -inset-[35%] rounded-full bg-[radial-gradient(circle,rgb(255_255_255/0.55)_0%,rgb(255_255_255/0)_65%)]" />
      <div className="dove-fly relative">
        <Image src="/dove.webp" alt="" width={420} height={493} priority sizes="150px" className="dove-glow h-auto w-full" />
      </div>
    </div>
  );
}
