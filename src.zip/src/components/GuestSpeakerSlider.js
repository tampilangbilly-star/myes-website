"use client";
import { useEffect, useRef, useState } from "react";
import clsx from "clsx";
import SmartImage from "./SmartImage";
import Icon from "./Icon";
import { formatDate } from "@/lib/format";

/** Kartu guest speaker: berganti halus tiap 5 detik, bisa di-swipe atau diketuk. */
export default function GuestSpeakerSlider({ speakers = [], lang = "en" }) {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const touchX = useRef(null);
  const total = speakers.length;
  const id = lang === "id";

  useEffect(() => {
    if (total < 2 || paused) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => document.visibilityState === "visible" && setI((c) => (c + 1) % total), 5000);
    return () => clearInterval(t);
  }, [total, paused]);

  if (!total) return null;
  const s = speakers[i % total];
  const move = (d) => setI((c) => (c + d + total) % total);

  return (
    <div
      className="card relative overflow-hidden p-4 sm:p-5"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={(e) => {
        touchX.current = e.touches[0].clientX;
        setPaused(true);
      }}
      onTouchEnd={(e) => {
        if (touchX.current === null) return;
        const dx = e.changedTouches[0].clientX - touchX.current;
        touchX.current = null;
        if (Math.abs(dx) > 40) move(dx < 0 ? 1 : -1);
      }}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.14em] text-primary-strong">
          <Icon name="mic" size={14} /> {id ? "Pembicara Tamu" : "Guest Speaker"}
        </p>
        {total > 1 && (
          <div className="flex items-center" role="tablist" aria-label={id ? "Pilih pembicara" : "Choose speaker"}>
            {speakers.map((sp, k) => (
              <button key={sp.id} type="button" role="tab" aria-selected={k === i} aria-label={sp.name} onClick={() => setI(k)} className="flex h-8 w-5 items-center justify-center">
                <span className={clsx("block h-1.5 rounded-full transition-all", k === i ? "w-4 bg-primary" : "w-1.5 bg-ink/20")} />
              </button>
            ))}
          </div>
        )}
      </div>

      <button type="button" onClick={() => total > 1 && move(1)} className="mt-3 flex w-full items-center gap-4 text-left" aria-label={total > 1 ? (id ? "Pembicara berikutnya" : "Next guest speaker") : s.name} disabled={total < 2}>
        <span key={s.id} className="animate-fade-in relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl bg-line sm:h-24 sm:w-24">
          <SmartImage src={s.image} alt={s.name} fill sizes="96px" className="object-cover" />
        </span>
        <span key={`t-${s.id}`} className="animate-fade-up min-w-0">
          <span className="block truncate font-display text-lg font-bold text-ink">{s.name}</span>
          {s.origin && <span className="mt-0.5 block text-sm text-ink-muted">{s.origin}</span>}
          <span className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-ink-soft">
            <Icon name="calendar" size={14} /> {formatDate(s.dateServed, lang)}
          </span>
        </span>
      </button>
    </div>
  );
}
